FoldBench 9 目标 PyMOL 叠图：橙色半透明为精修前，蓝绿色不透明为精修后。
1. 将整个 ZIP 解压到本地电脑。
2. 在 PyMOL 命令行先 cd 到解压后的 pymol_bundle_epoch49 文件夹。
3. 输入 @render_all.pml 批量生成 9 张图；或输入 @view_7sxp-assembly1.pml 只看一个目标。
4. 图片在 images/*_overlay.png；可编辑会话在 sessions/*.pse。
5. metrics.tsv 记录链长、本项目 RMSD 与 FoldBench RMSD/lDDT，方便制作 PPT 图注。
图像叠合使用磷原子，不等于本项目或 FoldBench 的 RMSD 计算。
